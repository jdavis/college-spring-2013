#ifndef CS229_H_
#define CS229_H_
#define WHITE 65535
#define BLACK 0
#define CS229COLOR
#define CS229BW
#include <stdio.h>

typedef unsigned short ushort;
typedef struct Image *ImagePtr;
typedef struct Pixel *PixelPtr;

/* all pixels are scaled to using an unsigned short regardless of their value
 * This makes it relatively easy to do operations, they are also bw/color agnostic until they are printed
 * */
struct Pixel {
	ushort r, g, b;

	/*int bwOrC;*/
};

struct Image {
	int width;
	int height;
	int bwOrC;
	int rChannel, gChannel, bChannel;

	PixelPtr *data;
};


void intToChars(int x);
int charsToInt();
ImagePtr readImage(FILE *fh);
ImagePtr emptyImage(int height, int width);
void writeImage(ImagePtr image);
void writePixel(FILE *fh, PixelPtr p, char rc, char gc, char bc, char bwOrColor);
struct Pixel readPixel(FILE *fh, char rc, char gc, char bc, char bwOrColor);
void printImageMeta(ImagePtr i);
void swapPixels(PixelPtr p1, PixelPtr p2);

PixelPtr getPixel(ImagePtr i, int w, int h);
int pow2(int e);
ushort scale(ushort s, char c, char u);

#endif
